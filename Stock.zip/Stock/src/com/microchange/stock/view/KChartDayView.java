package com.microchange.stock.view;

import java.math.BigInteger;
import java.util.List;

import com.microchange.stock.bean.MinuteInfo;
import com.microchange.stock.bean.SingleStockInfo;
import com.microchange.stock.util.CallBack;
import com.microchange.stock.util.KChartUtil;
import com.microchange.stock.util.Market;
import com.microchange.stock.util.StockService;
import com.microchange.stock.util.Type;

import android.content.Context;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;

public class KChartDayView extends KChartBaseView implements CallBack{
	
	List<SingleStockInfo> infos;
	List<MinuteInfo> minuteInfos;
	int per;// ÿһ��������ռ�Ŀ��ȣ�ÿ�����Ϊһ���㣬���Ե������Ϊ���м��λ��
	double highPrice;// ��߼�
	double lowPrice ;// ��ͼ�
	double maxCount;// ��ߵĳɽ�������
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		Log.e(TAG, " left:"+left+" top:"+kChartTop+" right:"+right+" bottom:"+KChartbottom);
		new StockService().getKchart("600875", 100, Market.SH,Type.DAY,this);
	}
	
	public void showTypeData(String stockCode, int count,Market market,Type type){
		new StockService().getKchart(stockCode, count,market,type,this);
	}
	
	
	public void showTypeData(String stockCode, Market market,Type type,String start){
		new StockService().getMinuteKchart(stockCode, start, market, type, this);
	}
	
	
	@Override
	protected void drawKChatBackGround() {
		Rect dirty = new Rect(left, kChartTop, right, KChartbottom);
		// ������ͼ�ľ���
		mCanvas.drawRect(dirty, LineGrayPaint);
		PathEffect effects = new DashPathEffect(new float[] { 5, 5, 5, 5 }, 1);
		LineGrayPaint.setPathEffect(effects);
		Path path = new Path();
		int y = kChartTop + 15;
		// �����������
		path.moveTo(left, y );
		path.lineTo(right, y );
		String text = getPriceText(highPrice);
		int textHeight = (int) (textGrayPaint.descent() - textGrayPaint.ascent());
		mCanvas.drawText(text,left - textGrayPaint.measureText(text) - 5,y + textHeight/2 ,textGrayPaint);
		double max = highPrice - lowPrice;
		if (max > 10){
			// �ֳ��ĵȷ�
			// ���м����������
			int n = 4;
			double sper = (highPrice - lowPrice) / 4;// ÿһ�ȷִ����ļ۸�
			for(int i=1;i<n;i++){
				y  =  i*((KChartbottom - kChartTop)/n) + kChartTop;
				path.moveTo(left, y);
				path.lineTo(right,y);
				text = getPriceText(highPrice - i*sper);
				mCanvas.drawText(text,left - textGrayPaint.measureText(text) - 5,y + textHeight/2,textGrayPaint);
			}
		}else{
			// �ֳ����ȷ�
			// ���м������
			y = (KChartbottom - kChartTop)/2 + kChartTop;
			path.moveTo(left, y);
			path.lineTo(right, y);
			text = getPriceText(highPrice - (highPrice - lowPrice) / 2);
			mCanvas.drawText(text,left - textGrayPaint.measureText(text) - 5,y + textHeight/2,textGrayPaint);
		}
		// �����������
		y = KChartbottom - 15;
		path.moveTo(left, y);
		path.lineTo(right, y);
		text = getPriceText(lowPrice);
		mCanvas.drawText(text,left - textGrayPaint.measureText(text) - 5,y + textHeight/2,textGrayPaint);
//		// ���ȷֵ����ߺ����������
		for (int i = num - 1; i > 0; i--) {
			int x = left + perWidth * i;
			path.moveTo(x, kChartTop);
			path.lineTo(x, KChartbottom);
			perXPoint[i - 1] = x;
		}
		mCanvas.drawPath(path, LineGrayPaint);
	}
	int[] perXPoint = new int[5];
	
	@Override
	protected void drawMAChart() {
		// ������
		Path path5 = new Path();
		Path path10 = new Path();
		Path path20 = new Path();
		double heightScale = (KChartbottom - kChartTop)/(highPrice - lowPrice);
		int maStart = left;
		float maStartY;
		path5.moveTo(maStart, (float) (kChartTop + (highPrice - infos.get(0).getMaValue5()) * heightScale));
		path10.moveTo(maStart, (float) (kChartTop + (highPrice - infos.get(0).getMaValue10()) * heightScale));
		path20.moveTo(maStart, (float) (kChartTop + (highPrice - infos.get(0).getMaValue20()) * heightScale));
		
		for(SingleStockInfo info:infos){
			maStart += per * perHalf;// ÿһ��ʵ����ռ��������4/6�����ұ߾��1/6 
			maStartY = (float) (kChartTop + (highPrice - info.getMaValue5()) * heightScale);
			path5.lineTo(maStart, maStartY);
			maStartY = (float) (kChartTop + (highPrice - info.getMaValue10()) * heightScale);
			path10.lineTo(maStart, maStartY);
			maStartY = (float) (kChartTop + (highPrice - info.getMaValue20()) * heightScale);
			path20.lineTo(maStart, maStartY);
			maStart += per * perHalf;
		}
		
		Paint paint = new Paint();
		paint.setColor(Color.BLUE);
		paint.setAntiAlias(true);
		paint.setStrokeWidth(2);
		paint.setStyle(Style.STROKE);
		mCanvas.drawPath(path5, paint);
		paint.setColor(Color.MAGENTA);
		mCanvas.drawPath(path10, paint);
		paint.setColor(Color.GREEN);
		mCanvas.drawPath(path20, paint);
	}
	
	/**
	 * �����ʮ����
	 */
	@Override
	protected void drawCrosshairsChart() {
		/**
		 * û�д�����ƽ�����
		 */
		int cLeft = left;
		float startY;
		float stopY;
		double heightScale = (KChartbottom - kChartTop)/(highPrice - lowPrice);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setStyle(Paint.Style.FILL);
		Rect dirty;
		int cTop = 0;
		int cRight;
		int cBottom = 0;
		int position = 0;
		int perPointX = perXPoint[position];// ��¼��һ����ֱ���ߵ�x����
		for(SingleStockInfo info:infos){
			cLeft += per * per16;// ÿһ��ʵ����ռ��������4/6������1/6
			if (cLeft >= perPointX){
				// ǡ�û�����һ����ֱ���ߵĵط�����Ҫ�����������
				String text = String.valueOf(info.getDate());
				text = text.substring(0, 4)+"-"+text.substring(4, 6);
				float textWidth = textGrayPaint.measureText(text);
				int textHeight = (int) (textGrayPaint.descent()- textGrayPaint.ascent());
				mCanvas.drawText(text, perPointX - textWidth/2, KChartbottom + textHeight, textGrayPaint);
				if (!(position==perXPoint.length-1)){
					perPointX = perXPoint[++position];
				}
			}
			cRight = (int) (cLeft + per * per46);
			if (info.getColor() == StockService.UP_COLOR){
				// �ɼ���
				cTop = (int) (kChartTop + (highPrice - info.getOpen()) * heightScale);
				cBottom = (int) (kChartTop + (highPrice - info.getClose()) * heightScale);
			}else if (info.getColor() == StockService.DOWN_COLOR){
				// �ɼ۵�
				cTop = (int) (kChartTop + (highPrice - info.getClose()) * heightScale);
				cBottom = (int) (kChartTop + (highPrice - info.getOpen()) * heightScale);
			}
			startY = (int) (kChartTop + (highPrice - info.getHigh()) * heightScale);
			stopY = (int) (kChartTop + (highPrice - info.getLow()) * heightScale);
			paint.setColor(info.getColor());
			dirty = new Rect(cLeft, cTop, cRight, cBottom);
			// ������ͼ�ľ���
			mCanvas.drawRect(dirty, paint);
			paint.setStrokeWidth(2);
			mCanvas.drawLine(cLeft + per * per26, startY, cLeft + per * per26, stopY, paint);
			cLeft += per * per56;// �ұߵļ�� 5/6
		}
	}
	
	private float per16 = 0.166666666f;
	private float per26 = 0.333333333f;
	private float perHalf = 0.5f;
	private float per56 = 0.833333333f;
	private float per46 = 0.666666666f;

	/**
	 * ���������ͼ
	 */
	@Override
	protected void drawPillarsChart(int flag) {
		LineGrayPaint.setPathEffect(null);
		Rect dirty = new Rect(left, pillarsChartTop, right, pillarsChartbottom);
		// ������ͼ�ľ���
		mCanvas.drawRect(dirty, LineGrayPaint);
		
		int y = pillarsChartTop + (pillarsChartbottom - pillarsChartTop)/2;
		mCanvas.drawLine(left,y,right, y, LineGrayPaint);
		
		// �м��ֵ
		String totalCount = getPriceText(maxCount/2/10000);
		float maginLeft = left - textGrayPaint.measureText(totalCount)- 5;
		mCanvas.drawText(totalCount, maginLeft, y,textGrayPaint);
		// �����ֵ
		totalCount = getPriceText(maxCount/10000);
		maginLeft = left - textGrayPaint.measureText(totalCount)- 5;
		mCanvas.drawText(totalCount, maginLeft, pillarsChartTop,textGrayPaint);
		// �����ֵ
		totalCount = "����";
		maginLeft = left - textGrayPaint.measureText(totalCount) - 5;
		mCanvas.drawText(totalCount, maginLeft, pillarsChartbottom,textGrayPaint);
		int pStart = left;
		float pStartY;
		double heightScale = (pillarsChartbottom - pillarsChartTop)/maxCount;
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setStyle(Paint.Style.FILL);
		if (flag == StockService.FLAG){
			for(MinuteInfo info:minuteInfos){
				pStart += per * per16;// ÿһ��ʵ����ռ��������4/6������1/6
				pStartY = (float) (pillarsChartTop + (maxCount - info.getVolume()) * heightScale);
				dirty = new Rect(pStart, (int) pStartY, (int) (pStart + per * per46), pillarsChartbottom-2);
				paint.setColor(info.getColor());
				// ������ͼ�ľ���
				mCanvas.drawRect(dirty, paint);
				pStart += per * per56;// �ұߵļ�� 5/6
			}
		}else{
			for(SingleStockInfo info:infos){
				pStart += per * per16;// ÿһ��ʵ����ռ��������4/6������1/6
				pStartY = (float) (pillarsChartTop + (maxCount - info.getTotalCount()) * heightScale);
				dirty = new Rect(pStart, (int) pStartY, (int) (pStart + per * per46), pillarsChartbottom-2);
				paint.setColor(info.getColor());
				// ������ͼ�ľ���
				mCanvas.drawRect(dirty, paint);
				pStart += per * per56;// �ұߵļ�� 5/6
			}
		}
	}
	
	/**
	 * ��ʱͼ
	 */
	@Override
	public void drawHoursChart(){
		double heightScale = (KChartbottom - kChartTop)/(highPrice - lowPrice);
		int cLeft = left;
		int cTop = 0;
		Path path = new Path();
		path.moveTo(cLeft, KChartbottom-2);
		int position = 0;
		int perPointX = perXPoint[position];// ��¼��һ����ֱ���ߵ�x����
		for(MinuteInfo info:minuteInfos){
			cLeft += per * per16;
			cTop = (int) (kChartTop + (highPrice - info.getNow()) * heightScale);
			path.lineTo(cLeft + per * per26, cTop);
			if (cLeft >= perPointX){
				// ǡ�û�����һ����ֱ���ߵĵط�����Ҫ�������ʱ��
				String text = KChartUtil.getMinute(info.getMinute());
				float textWidth = textGrayPaint.measureText(text);
				int textHeight = (int) (textGrayPaint.descent()- textGrayPaint.ascent());
				mCanvas.drawText(text, perPointX - textWidth/2, KChartbottom + textHeight, textGrayPaint);
				if (!(position == perXPoint.length-1)){
					Log.e(TAG, perPointX+"----------"+info.getMinute()+"---"+text);
					perPointX = perXPoint[++position];
				}
			}
			cLeft += per * per56;// �ұߵļ�� 5/6
		}
		path.lineTo(cLeft, KChartbottom-2);
		Paint LinePaint = new Paint();
		LinePaint.setColor(Color.BLUE);
		LinePaint.setAntiAlias(true);
		LinePaint.setStrokeWidth(1);
		LinePaint.setStyle(Style.STROKE);
//		LinePaint.setStyle(Style.STROKE);
		mCanvas.drawPath(path, LinePaint);
		LinePaint.setAlpha(50);
		LinePaint.setStyle(Style.FILL);
		mCanvas.drawPath(path, LinePaint);
	}
	
	public String getPriceText(double price){
		return String.format("%.2f",price);
	}
	
	public void touch(float x,float y){
//		Log.e(TAG, x+"---"+y);
//		mCanvas = mSurfaceHolder.lockCanvas();
//		mCanvas.drawLine(x, y, x,KChartbottom,LineGrayPaint);
//		mSurfaceHolder.unlockCanvasAndPost(mCanvas);
	}
	
	/**
	 * ��ʼ��
	 */
	public void startDraw(final int flag){
		new Thread(){
			public void run() {
				try {
					mCanvas = mSurfaceHolder.lockCanvas();
					clearCanvas();
					if (flag == StockService.FLAG){
						int size = minuteInfos.size();
						per = totalWidth / size;// ÿһ�����ӵĿ���
						perWidth = totalWidth / num;// ÿһ�����ݵĶ����
						highPrice = minuteInfos.get(0).getNow();// ��߼�
						lowPrice = minuteInfos.get(0).getNow();
						maxCount = minuteInfos.get(0).getVolume();
						for(MinuteInfo info:minuteInfos){
							if (highPrice<info.getNow()){
								highPrice = info.getNow();
							}
							if (lowPrice>info.getNow()){
								lowPrice = info.getNow();
							}
							maxCount = Math.max(maxCount, info.getVolume());
						}
					}else{
						int size = infos.size();
						per = totalWidth / size;// ÿһ�����ӵĿ���
						perWidth = totalWidth / num;// ÿһ�����ݵĶ����
						highPrice = infos.get(0).getHigh();// ��߼�
						lowPrice = infos.get(0).getLow();
						maxCount = infos.get(0).getTotalCount();
						for(SingleStockInfo info:infos){
							highPrice = Math.max(highPrice, info.getHigh());
							lowPrice = Math.min(lowPrice, info.getLow());
							maxCount = Math.max(maxCount, info.getTotalCount());
						}
					}
					Log.e(TAG, "highPrice:"+highPrice+"  lowPrice:"+lowPrice+"  maxCount"+maxCount);
					drawChartType(flag);
				} catch (Exception e) {
					Log.e(TAG, e.getMessage());
				}finally{
					try {
						mSurfaceHolder.unlockCanvasAndPost(mCanvas);
					} catch (Exception e) {
					}
				}
			};
		}.start();
	}
	
	
	@Override
	public void success(Object o,int flag) {
		if (flag == StockService.FLAG){
			// ��ʱ
			minuteInfos = (List<MinuteInfo>) o;
			if (minuteInfos!=null && !minuteInfos.isEmpty()){
				startDraw(flag);
			}
		}else{
			infos = (List<SingleStockInfo>) o;
			if (infos!=null && !infos.isEmpty()){
				startDraw(flag);
			}
		}
		
	}

	/**
	 * ��ջ���
	 */
	public void clearCanvas() {
		Paint paint = new Paint();
		paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
		mCanvas.drawPaint(paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC));
	}
	
	public KChartDayView(Context context) {
		super(context);
	}

	public KChartDayView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public KChartDayView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}


	@Override
	public void before(Object o) {
		
	}


	

	@Override
	public void failer(Object o) {
		
	}

	
	
	
	
	
	
}
