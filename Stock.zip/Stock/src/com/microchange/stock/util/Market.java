package com.microchange.stock.util;

public enum Market {
	SH("SH"), SZ("SZ");
	private String value;

	Market(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}