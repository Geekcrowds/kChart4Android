package com.microchange.stock.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.microchange.stock.bean.MinuteInfo;
import com.microchange.stock.bean.SingleStockInfo;

import android.graphics.Color;

/**
 * http://wxhq.essence.com.cn/market/json?funcno=20002&version=1&stock_code=
 * 600875& type=day&count=100&market=SH
 *
 */
public class StockService {
	
	public static final String FUNC_NO = "20002";
	public static final String FUNC_HOUR_NO = "20001";
	public static final String VERSION = "1";
	public  static final int UP_COLOR = 0xffd70b17;
	public  static final int DOWN_COLOR = 0xff339900;
	public static final String URI = "http://wxhq.essence.com.cn/market/json";
	public static final int FLAG = 0;// ��ʱ

	/**
	 * ��ȡ��k����k ����K
	 * @param stockCode
	 * @param count
	 * @param market
	 * @param type
	 * @param callBack
	 */
	public  void getKchart(final String stockCode, 
			final int count,final  Market market,final Type type, final CallBack callBack) {
		if (callBack != null)callBack.before(null);
		new Thread(){
			public void run() {
				Map<String, String> map = new HashMap<String, String>();
				map.put("funcno", FUNC_NO);
				map.put("version", VERSION);
				map.put("stock_code",stockCode);
				map.put("type", type.getValue());
				map.put("count",String.valueOf(count) );
				map.put("market", market.getValue());
				String resultJson = sendPost(map);
				if (resultJson!=null){
					try {
						List<SingleStockInfo> infos = processKChartJson(resultJson, map);
						callBack.success(infos,-1);
					} catch (Exception e) {
						e.printStackTrace();
						callBack.failer(null);
					}
				}else{
					callBack.failer(null);
				}
			};
		}.start();
	}
	/**
	 * funcno=20001&version=1&stock_code=600875&start=""&market=SH
	 */
	public  void getMinuteKchart(final String stockCode, 
			final String start,final  Market market,final Type type, final CallBack callBack) {
		if (callBack != null)callBack.before(null);
		new Thread(){
			public void run() {
				Map<String, String> map = new HashMap<String, String>();
				map.put("funcno", FUNC_HOUR_NO);
				map.put("version", VERSION);
				map.put("stock_code",stockCode);
				map.put("market", market.getValue());
				map.put("start", start);
				String resultJson = sendPost(map);
				if (resultJson!=null){
					try {
						List<MinuteInfo> infos = processMiuteKchatJson(resultJson);
						callBack.success(infos,FLAG);
					} catch (Exception e) {
						e.printStackTrace();
						callBack.failer(null);
					}
				}else{
					callBack.failer(null);
				}
			};
		}.start();
	}

	public List<MinuteInfo> processMiuteKchatJson(String resultJson){
		List<MinuteInfo> minuteInfos = new ArrayList<MinuteInfo>();
		try {
			JSONObject jsonObject = new JSONObject(resultJson);
			JSONArray jsonArray = jsonObject.getJSONArray("results");
			if (jsonArray.length() > 0) {
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONArray minuteArray = jsonArray.getJSONArray(i);
					int minute = minuteArray.getInt(0);
					double now = minuteArray.getDouble(1);
					double avgPrice = minuteArray.getDouble(2);
					double volume = minuteArray.getDouble(3);
					MinuteInfo minuteInfo = new MinuteInfo("",minute, now, avgPrice, volume);
					if (now > avgPrice){
						minuteInfo.setColor(UP_COLOR);
					}else{
						minuteInfo.setColor(DOWN_COLOR);
					}
					minuteInfo.setType(Type.HOUR);
					minuteInfos.add(minuteInfo);
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return minuteInfos;
	}
	
	public List<SingleStockInfo> processKChartJson(String mResult,Map<String, String> mParam) throws Exception{
		JSONObject jsonObject = new JSONObject(mResult);
		List<SingleStockInfo> infos = new ArrayList<SingleStockInfo>();
		int errorCode = jsonObject.getInt("errorNo");
		String errorMessage = jsonObject.getString("errorInfo");
		if (0 == errorCode) {
			JSONArray array = jsonObject.getJSONArray("results");
			Type type = Type.DAY;
			if ("day".equals(mParam.get("type"))) {
				type = Type.DAY;
			}
			if ("week".equals(mParam.get("type"))) {
				type = Type.WEEK;
			}
			if ("month".equals(mParam.get("type"))) {
				type = Type.MONTH;
			}
			int multiple = 100;
//			String mType = mParam.get("type");// ��Ʊ���
			String mType = "9";// ��Ʊ���
			if (null != mType&& ("0".equals(mType) || "1".equals(mType)|| "2".equals(mType) || "9".equals(mType)
							|| "7".equals(mType) || "15".equals(mType) || "18".equals(mType))) {
				multiple = 100;
			} else {
				multiple = 1000;
			}
			int index = 0;
			/**
			 * ���ݽ�ֹ����һ��������
			 */
			if (null != array && array.length() > 0) {
				while (index < array.length()) {
					JSONArray tmp = array.getJSONArray(index);
					int color = tmp.getDouble(1) > tmp.getDouble(3)?DOWN_COLOR:UP_COLOR;// ����ǵ��������ɫΪ��ɫ  ������ǣ������ɫΪ��ɫ
					double open = tmp.getDouble(1) / multiple; // ���̼�
					double close = tmp.getDouble(3) / multiple; // ���̼�
					double high = tmp.getDouble(2) / multiple;// ��߼�
					double low = tmp.getDouble(4) / multiple;// ��߼�
					int date = tmp.getInt(0);// ����
					double totalCount = tmp.getDouble(5) / 100;// һ��ɽ��ɽ����������ܳɽ���
					double totalPrice = tmp.getDouble(6);// �ܳɽ����;
					SingleStockInfo singleStockInfo = new SingleStockInfo();
					singleStockInfo.setColor(color);
					singleStockInfo.setClose(close);
					singleStockInfo.setDate(date);
					singleStockInfo.setHigh(high);
					singleStockInfo.setLow(low);
					singleStockInfo.setOpen(open);
					singleStockInfo.setTotalCount(totalCount);
					singleStockInfo.setTotalPrice(totalPrice);
					infos.add(singleStockInfo);
					singleStockInfo.setType(type);
					index++;
				}
			}
		}
		KChartUtil.calcMAF2T(infos, 5);
		KChartUtil.calcMAF2T(infos, 10);
		KChartUtil.calcMAF2T(infos, 20);
		return infos;
	}
	
	
	public String sendPost(Map<String, String> params) {
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(URI);
		// ������ʱ
		HttpParams httpParams = new BasicHttpParams();//
		HttpConnectionParams.setConnectionTimeout(httpParams, 8000);
		HttpConnectionParams.setSoTimeout(httpParams, 8000);
		post.setParams(httpParams);
		try {
			// ���ò���
			if (params != null && params.size() > 0) {
				List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
				for (Map.Entry<String, String> item : params.entrySet()) {
					BasicNameValuePair pair = new BasicNameValuePair(item.getKey(), item.getValue());
					parameters.add(pair);
				}
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(parameters, "utf-8");
				post.setEntity(entity);
				HttpResponse response = client.execute(post);
				if (response.getStatusLine().getStatusCode() == 200) {
					return EntityUtils.toString(response.getEntity(),"utf-8");
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * ����get����
	 */
	public void sendGet(final String uri, final CallBack callBack) {
		new Thread() {
			public void run() {
				HttpClient client = new DefaultHttpClient();
				HttpGet get = new HttpGet(uri);
				try {
					HttpResponse response = client.execute(get);
					if (response.getStatusLine().getStatusCode() == 200) {
						callBack.success(EntityUtils.toString(
								response.getEntity(), "utf-8"),-1);
					} else {
						callBack.failer(null);
					}
				} catch (Exception e) {
					e.printStackTrace();
					callBack.failer(null);
				}
			};
		}.start();
	}
	
	
}
