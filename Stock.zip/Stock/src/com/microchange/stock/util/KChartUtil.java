package com.microchange.stock.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.microchange.stock.bean.SingleStockInfo;

import android.R.integer;

public class KChartUtil {

	public static String getDateYYYYMM(int offset) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, offset);
		return calendar.get(Calendar.YEAR) + "-" + calendar.get(Calendar.MONTH);
	}

	public static int getMonth() {
		return Calendar.getInstance().get(Calendar.MONTH);
	}

	public static int getDayOfMonth(int offset) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, offset);
		return calendar.get(Calendar.DAY_OF_MONTH);
	}

	public static String getMinute(int minute) {
		int hour = minute / 60;// ʱ
		int min = minute % 60;// ��
		return hour + ":" + (min);
	}

	public static void calcMA(SingleStockInfo kChartDayBean, int days,
			int position) {
		if (days < 2) {
			return;
		}
		float sum = 0;
		float avg = 0;
		float close = (float) kChartDayBean.getClose();
		if (position < days) {
			sum = sum + close;
			avg = sum / (position + 1f);
		} else {
			sum = sum + close - (float) (float) kChartDayBean.getClose();
			avg = sum / days;
		}
		if (days == 5) {
			kChartDayBean.setMaValue5(avg);
		} else if (days == 10) {
			kChartDayBean.setMaValue10(avg);
		} else if (days == 20) {
			kChartDayBean.setMaValue20(avg);
		}
	}

	/**
	 * �������
	 * 
	 * @param kChartDayBean
	 * @param days
	 * @return
	 */
	public static List<SingleStockInfo> calcMAF2T(
			List<SingleStockInfo> kChartDayBean, int days) {

		if (days < 2) {
			return null;
		}

		float sum = 0;
		float avg = 0;
		for (int i = 0; i < kChartDayBean.size(); i++) {
			float close = (float) kChartDayBean.get(i).getClose();
			if (i < days) {
				sum = sum + close;
				avg = sum / (i + 1f);
			} else {
				sum = sum
						+ close
						- (float) (float) kChartDayBean.get(i - days)
								.getClose();
				avg = sum / days;
			}
			// kChartDayBean.get(i).setMaValue5(avg);
			if (days == 5) {
				kChartDayBean.get(i).setMaValue5(avg);
			} else if (days == 10) {
				kChartDayBean.get(i).setMaValue10(avg);
			} else if (days == 20) {
				kChartDayBean.get(i).setMaValue20(avg);
			}
		}
		return kChartDayBean;
	}

}
