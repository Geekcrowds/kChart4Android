package com.microchange.stock.util;

public interface CallBack {
	public void before(Object o);
	public void success(Object o,int flag);
	public void failer(Object o);
	
}
