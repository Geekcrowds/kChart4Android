package com.microchange.stock.activity;

import com.microchange.stock.R;
import com.microchange.stock.util.Market;
import com.microchange.stock.util.Type;
import com.microchange.stock.view.KChartDayView;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

public class StockActivity extends Activity {
	private TextView typeTv;
	private KChartDayView kChartView;
	private ProgressBar progressBar;
	private String stockCode = "600875";// ��������
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_kchart);
		kChartView = (KChartDayView) findViewById(R.id.day);
		typeTv = (TextView) findViewById(R.id.type);
		progressBar = (ProgressBar) findViewById(R.id.pb);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		kChartView.touch(event.getX(),event.getY());
		return super.onTouchEvent(event);
	}
	
	public void showMonth(View view){
		typeTv.setText("��K");
		kChartView.showTypeData(stockCode, 100, Market.SH,Type.MONTH);
	}
	public void showWeek(View view){
		typeTv.setText("��K");
		kChartView.showTypeData(stockCode, 100, Market.SH,Type.WEEK);
	}
	public void showDay(View view){
		typeTv.setText("��K");
		kChartView.showTypeData(stockCode, 100, Market.SH,Type.DAY);
	}
	public void showHour(View view){
		typeTv.setText("��ʱ��");
		kChartView.showTypeData(stockCode, Market.SH, Type.HOUR, "");
	}
}
