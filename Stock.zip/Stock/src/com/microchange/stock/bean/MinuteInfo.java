package com.microchange.stock.bean;

import com.microchange.stock.util.StockService;
import com.microchange.stock.util.Type;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * <strong>��װ��ʱͼ��Ϣ</strong>
 */
public class MinuteInfo implements Parcelable {

    //����
    private String date;

    //������
    private int minute;

    //�ּ�
    private double now;

    //����
    private double avgPrice;

    //�ɽ���
    private double volume;

    private Type type;
    
    private int color;
    
    public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public MinuteInfo() {

    }

    public MinuteInfo(String date,int minute, double now, double avgPrice, double volume) {
        this.date = date;
        this.minute = minute;
        this.now = now;
        this.avgPrice = avgPrice;
        this.volume = volume;
    }

    public MinuteInfo(Parcel source) {
        this.date = source.readString();
        this.minute = source.readInt();
        this.now = source.readDouble();
        this.avgPrice = source.readDouble();
        this.volume = source.readDouble();
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public double getNow() {
        return now;
    }

    public void setNow(double now) {
        this.now = now;
    }

    public double getAvgPrice() {
        return avgPrice;
    }

    public void setAvgPrice(double avgPrice) {
        this.avgPrice = avgPrice;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(date);
        dest.writeInt(minute);
        dest.writeDouble(now);
        dest.writeDouble(avgPrice);
        dest.writeDouble(volume);
    }

    public static final Creator<MinuteInfo> CREATOR = new Creator<MinuteInfo>() {
        @Override
        public MinuteInfo createFromParcel(Parcel source) {
            return new MinuteInfo(source);
        }

        @Override
        public MinuteInfo[] newArray(int i) {
            return new MinuteInfo[i];
        }
    };

}
