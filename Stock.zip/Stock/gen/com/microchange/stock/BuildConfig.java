/** Automatically generated file. DO NOT MODIFY */
package com.microchange.stock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}